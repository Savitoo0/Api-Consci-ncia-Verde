    // src/app/components/OtherSection.tsx

    const OtherSection = () => {
        return (
            <div className="other-section">
                <h2>Seção Adicional</h2>
                <p>Aqui você pode adicionar qualquer conteúdo extra que desejar.</p>
            </div>
        );
    };

    export default OtherSection;
    